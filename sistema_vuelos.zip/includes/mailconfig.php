<?php

// agregar a .gitignore.


define('MAIL_USERNAME', 'sistemavuelos@gmail.com');
define('MAIL_PASSWORD', 'wgfw hmjr hpge bjtm');